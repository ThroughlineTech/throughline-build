# Conductor: drive a Plane backlog safely (`run-backlog`)

This is the agent-agnostic, repo-agnostic procedure for acting as the CONDUCTOR over a
repo's `build`/Plane backlog: drive it forward ticket by ticket, implementing each ticket
and then INDEPENDENTLY reviewing it, with a rework loop. Repos may opt into Build-backed
parallel fan-out for genuinely disjoint tickets. Plane is the system of record. It applies
in any repo wired for `build` (has a `.build/config.toml`).

It deliberately holds NO repo specifics. Everything that differs per repo - the gate
commands, the source roots, the review invariants, the deploy/irreversible steps, the
branch prefix, how the backlog is grouped, and any review-model escalation rule - lives
in the **`## Conductor inputs`** section of that repo's `AGENTS.md`. **Read that section
at your cwd before you start.** If the repo has no `Conductor inputs` section, stop and
tell the human; do not guess the gates or invariants.

## Inputs you are given

- **SCOPE**: what to do this run (passed by the human / the calling entry point). Interpret:
  - a GROUPING identifier (an epic id like `PROJ-30`, or a phase like `P0` - the repo's
    `Conductor inputs` says which it uses): do every unfinished child/member in order,
    then STOP and report.
  - `next N`: do the N lowest-ordered unfinished, actionable tickets (state Todo / Ready /
    In Progress), then STOP.
  - an explicit list of ids (`PROJ-41 PROJ-42`): do exactly those, in the given order, then STOP.
  - EMPTY: do the single next actionable ticket (lowest-ordered in Ready, else Todo), then STOP.

  "Unfinished" = state is not Done and not Cancelled. NEVER pull a ticket out of Backlog or
  Planning unless it is named explicitly in SCOPE.

## Independence is the invariant (not the mechanism)

The value of this loop is that review is INDEPENDENT of implementation. Hold that invariant
however your tool lets you:

- **If you can spawn subagents** (e.g. a sub-agent / task tool): run the implementer as one
  worker, then the reviewer as a SEPARATE worker given only the ticket + the diff.
- **If you can reset context but not spawn**: do the implement pass, then drop that reasoning
  and re-derive the review from `git diff` + the ticket body alone.
- **If you have a single context only**: review adversarially against the real tree as if
  someone else wrote it.

In every case the reviewer MUST re-run the gates for real, check every acceptance-criterion
line against the actual tree, and treat the implementer's self-assessment as unverified.

## Plane access

All ticket reads/writes go through the `build` CLI - see `~/src/AGENTS-build-cli-instructions.md`.
`build` finds the project from the `.build/config.toml` at your cwd; you do NOT need creds,
URLs, project UUIDs, or an API token, and you do NOT hand-roll `curl` against the REST API.
Learn this repo's ticket prefix by running `build list` (first column). If `build` fails with
`config file not found`, the repo is not wired - stop and tell the human.

ASCII ONLY in any Plane body/comment (the API mangles non-ASCII). For a long comment or body,
feed it via stdin (`build comment <ID> -`) or a path (`build amend <ID> --description <path>`).

## Setup (once per run)

1. Read the SCOPE's parent/epic/phase (if named) for strategy, decisions, risks, and what is
   out of scope. Skim the repo's architecture map (its `Conductor inputs` names the doc root).
2. git: NEVER commit to main. Create/checkout the run branch yourself using the repo's branch
   prefix (from `Conductor inputs`, e.g. `<prefix>-<slug>`). If the primary worktree is on `main`
   or another forbidden branch and the tree is otherwise safe, this is an automatic setup step, not
   a human decision. If the branch exists locally, switch to it; otherwise create it from the
   configured base branch/ref. Refuse only on dirty tracked changes, unresolved branch ambiguity, or
   a branch that exists with unrelated unsafe state. Do NOT open a PR, merge, deploy, or install on
   a device unless the human explicitly says so.
3. Integration target: treat `INTEGRATION_TARGET=refs/heads/<branch>` in SCOPE as an optional
   override, not a required user-provided token. When it is absent, set it internally to the full
   local ref for the run branch you just selected or created. Never ask the human to run
   `git switch -c ...` or to rerun `/run-backlog` with an `INTEGRATION_TARGET` when the conductor
   can prove and perform that setup safely.

## Per-ticket loop

For each ticket in order (respect any "Dependencies" block in the body - do not start a ticket
whose stated dependencies are not Done):

**A. SELECT + CLAIM.** Fetch the ticket (`build get <ID>`). Move it to In Progress
(`build transition <ID> InProgress`). Post a one-line comment "Conductor: starting."

**B. IMPLEMENT.** Dispatch ONE implementer (see "Independence" above). Give it the ticket's
FULL body, the repo path (cwd), and the source roots from `Conductor inputs`. Implementer
instructions: implement EXACTLY this ticket's scope (no more, no less); read the cited files
BEFORE writing (start at the contract-authority file when the ticket touches a shared wire
shape); match existing conventions; run any repo-specific pre-step the gates require (e.g. a
project-file regen); then run the GATES yourself and paste real output. Report: files changed,
commands run + verbatim results, and a self-check of EACH acceptance-criterion line (met /
not-met + why). It must NOT commit, switch branches, or touch tickets. In serial mode, do tickets
sequentially. In fan-out mode, there is still only one writer per worktree.

**C. REVIEW (independent).** Move the ticket to In Review. Run the reviewer with fresh context
(see "Independence"). Give it ONLY the ticket body + the implementer's reported diff/summary;
tell it to treat the self-assessment as unverified. Reviewer: independently (1) run the gates
itself (`git diff` to see the actual change, then the repo's gate commands) and (2) check every
acceptance-criterion line against the real tree, plus correctness, scope-creep, and the repo's
**review invariants** (from `Conductor inputs`). Returns a strict verdict: PASS or REWORK, the
gate results, any unmet acceptance criteria, and specific actionable findings (`file:line` + fix).

**Model selection.** Dispatch both the implementer (step B) and the reviewer (step C)
inheriting the ambient model by default - do not override. Exception: if the repo's
`Conductor inputs` names a review-model escalation rule and this ticket matches its
trigger (e.g. touches the wire contract, touches auth/security logic), dispatch the
REVIEWER on that stronger model for this ticket. The implementer stays on the ambient
model regardless - escalation is a review-quality safety net, not a blanket upgrade.
If a repo names no such rule, do not invent one.

**D. DECIDE.**
- **PASS**: commit the work (`<ID>: <title>`), move the ticket to Done, and post a comment
  summarizing what landed (files, gates green) - ASCII only. Next ticket.
- **REWORK**: move the ticket back to In Progress, post the reviewer's findings as a comment,
  and re-dispatch the implementer (step B) with those findings prepended as
  "Rework - address these:". Re-review (step C). Cap at 3 rework rounds per ticket. After 3
  failed rounds, leave the ticket In Review, post "Conductor: escalating after 3 rework rounds"
  with the blocking findings, STOP the run, and surface it to the human. Do not force a ticket Done.

## Parallel fan-out (OPTIONAL - only when the repo declares it)

The per-ticket loop above is SERIAL by default, and that is the correct default. A repo MAY opt
into running independent tickets concurrently by declaring a **`Fan-out inputs`** block inside its
`## Conductor inputs` and configuring Build primitives in `.build/config.toml` (`[worktree]`,
`[waves]`, `[[waves.serialize]]`, and real `[[review.checks]]`). If the block is absent, the Build
config is missing, or the repo still points at obsolete local scripts, stay serial and report the
stale declaration. Do NOT invent a fan-out mechanism. Independence, the gates, the invariants, and
"never deploy/merge in the loop" all still hold unchanged; fan-out only changes HOW MANY tickets are
in-flight, never what a ticket's loop is.

When the repo declares fan-out, replace "do tickets sequentially" with:

1. **Level the DAG.** Bucket the SCOPE's tickets into dependency levels from their Dependencies
   blocks. A ticket never runs before any dep it names.
2. **Plan disjoint waves.** Within a level, predict each ticket's files conservatively. Use
   `uncertain: true` for incomplete or doubtful predictions. Verify external dependencies and pass
   them as `verifiedExternalDeps`. Run `build waves --input <json> --json`; it uses exact file
   overlap plus the repo's `[waves]` / `[[waves.serialize]]` rules. Print the wave plan; never
   silently serialize or silently parallelize. A nonzero exit means the plan is unsafe.
3. **Fan out one WAVE at a time**, capped at the repo's declared concurrency (small - the bound is
   the machine/gates, not the model). For each ticket in the wave: lease an ISOLATED workspace with
   `build worktree lease --ticket <ID> --slug <slug> --base <base-ref> --json`, adding
   `--require-seed <path>` only when that ticket truly needs an allowlisted seed. Inspect the JSON
   result. Run the ticket's implement -> review -> rework loop (steps B/C/D above) with the
   worker's cwd = that worktree. THE CONDUCTOR OWNS THE WORKSPACE LIFECYCLE - do not use any
   per-agent "fresh workspace" isolation, because the reviewer must see the implementer's tree and
   rework round 2 must resume round 1's tree.
4. **Integrate serially.** Use the full local ref for the run branch selected/created during setup
   as the shared integration target unless SCOPE supplied a validated `INTEGRATION_TARGET`
   override. After a wave's tickets pass, integrate them ONE AT A TIME in ticket
   order onto the shared branch. Commit inside the ticket worktree, rebase the helper branch onto
   the current shared branch, stop on conflicts, then fast-forward the shared branch. After the wave
   applies, run the configured integrated gate, preferably
   `build gate --ticket <scope-or-wave> --require-checks --json`, on the merged tree. A green
   per-workspace gate does not prove the merged tree is green; a conflict here means the wave plan
   missed an overlap - surface it, do not paper over it.
5. **Tear down** the wave's workspaces with
   `build worktree teardown --ticket <ID> --require-merged-into <shared-branch> --json`, then take
   the next wave. Use `--force` only with explicit human approval.

Enforcement note: ALL git history writes and ALL ticket-state changes stay with the conductor in the
PRIMARY workspace; workers in leased workspaces are read-implement-gate only and must not commit,
switch branches, integrate, tear down worktrees, or touch tickets. A repo MAY back this with a deny
hook keyed on "am I in a leased workspace"; where it cannot, it stays a hard instruction to the
worker.

Honest expectation: fan-out pays only on the genuinely disjoint subset, typically ~2x net on a
realistic batch (not across the board) once per-workspace setup + serial integration are counted.
If a scope's tickets are mostly file-overlapping, the pre-flight will collapse them back to serial -
that is the system working, not a failure.

## Guardrails

- **Human-in-the-loop for physical / irreversible steps.** Do everything automatable, then
  PAUSE with exact copyable steps and wait - never fake a green gate. The repo's `Conductor
  inputs` names its irreversible boundaries (deploy, install-on-device, real-device checks).
- **NEVER deploy, merge to main, or install on a device inside the loop.** Building and testing
  is one thing; shipping is a separate, explicit step you wait for the human to authorize. The
  exact deploy steps live in `Conductor inputs`.
- **One SCOPE-UNIT per run by default.** After the scope's last ticket, STOP and post a summary
  comment on the epic/phase/parent (tickets Done, escalations, branch name). Do not roll into
  more work, merge, or deploy without the human.
- **Scope discipline.** Implementers do exactly their ticket. If a ticket reveals missing work,
  note it as a finding for the human (or a new Plane ticket); do not silently expand.
- **Keep the ticket current** as you go (it is the record). ASCII everywhere in Plane.
- **If launched with `--notify` / `--prowl`**, fire `~/src/notify.sh` at scope completion or on
  escalation (see the Notifications section of `~/src/AGENTS.md`).

## Report

End every run with: the branch name, a table of tickets touched and their final Plane state,
gate results, any escalations needing the human, and the single recommended next action.
