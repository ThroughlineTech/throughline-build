# Prompt: simplify run-backlog in this repository

One of this kit's two entry points. Use it - rather than [README.md](README.md) - when the target
repository ALREADY has hand-rolled `run-backlog` machinery and the human wants it SERIAL. It
removes that machinery, moves the gate into configuration, and installs the ticket transaction. It
does NOT change how tickets are read or written.

Give it to a coding agent whose cwd is the target repository. Same two-directory rule as the
README: **KIT_DIR** is read-only, **REPO** is the only place you write.

Fresh repository with no run-backlog at all? Wrong file - use [README.md](README.md).

**Serial does not mean looser.** [procedure/ticket-transaction.md](procedure/ticket-transaction.md)
is the lifecycle either way: the conductor still baselines before implementing, still commits only
after an independent review PASS, and still marks a ticket Done only after the commit is integrated
and the merged tree is green. What you are removing is the SCHEDULING layer, not the transaction.

## Background you need before you touch anything

`run-backlog` is a deliberate blend of two tools:

- **`build` (Throughline Build) does the deterministic work** - ticket CRUD (`list`, `get`,
  `comments`, `comment`, `transition`, `amend`) plus workspace lifecycle, gating, and wave planning
  (`build worktree`, `build gate`, `build waves`). None of those three spawns a worker agent.
- **Your session does the agentic work** - you are the conductor. You keep repository context warm
  across the run and spawn your OWN subagents for implement and review.

`build chain` (and `plan` / `implement` / `review` / `ship`) is the deliberately-rejected
alternative: same pipeline, a fresh worker CLI process per phase, a cold context load every time.
**This is settled. Do not propose adopting `build chain` as part of this cleanup.** If the repo
never uses the pipeline verbs, that is the design working.

Confirm the verbs exist before you rely on them:

```sh
build worktree --help && build gate --help && build waves --help
```

## Step 1 - Determine which path this repo is on

Read the repository's `AGENTS.md` (or `CLAUDE.md`) `## Conductor inputs` section, and look for
worktree, preflight, or lease scripts.

- **No fan-out block and no such scripts** -> already serial. Skip Steps 3 and 4; do Steps 5-8. The
  gate consolidation and the transaction are what actually fix runaway rework and premature Done.
- **Fan-out machinery present** -> the human must choose:
  - **(a) Go serial.** Do the whole prompt. Right default if the batches were not genuinely
    file-disjoint, or if fan-out cost more integration pain than it saved.
  - **(b) Keep fan-out, on Build's primitives.** Do Steps 2-4 (remove the hand-rolled version),
    then switch to [README.md](README.md) and run its Steps 1-8 instead of Steps 5-7 here.

  **ASK the human which one.** Do not decide it yourself.

## Step 2 - Inventory before deleting

```sh
git grep -ln "worktree\|preflight\|fan-out\|lease" -- '*.md' '*.json' '*.mjs' '*.js' '*.py' '*.sh' \
  | grep -vi node_modules
ls .claude/agents .claude/hooks .claude/commands 2>/dev/null
cat .claude/settings.json 2>/dev/null
```

Report the inventory before removing anything. Some hits are unrelated domain usage (for example
"push fan-out" in application code). Only run-backlog conductor machinery is in scope.

## Step 3 - Remove the hand-rolled fan-out apparatus

Adapt to what Step 2 found. Typically: the worktree lease/teardown helper, the wave-planning
preflight script **and any test file covering it** (easy to miss; it will fail the gate), any
integrator agent definition, the fan-out block in `## Conductor inputs`, gitignore entries for the
old worktree root and lease manifests, and the now-empty worktree root.

On path (a), also remove any `PreToolUse` deny hook whose only job is policing worker git/ticket
operations, and the settings file registering it **if the hook was its only content** - read it
first. (On path (b) the hook stays: it is the only structural enforcement of conductor-owns-git,
and Build has no equivalent.)

Replace the removed fan-out block with a short note so the next agent knows it was intentional:

```
- **Parallelism:** NOT declared. This repo runs the conductor loop SERIALLY, one ticket at a
  time. Worktree-based fan-out was removed on <date>. Build now exposes the deterministic
  primitives (`build worktree`, `build gate`, `build waves`), so if fan-out is wanted again,
  install the build-backed run-backlog fan-out kit - do not reintroduce repo-local fan-out
  scripts. The per-ticket lifecycle is unchanged either way: see <path to
  procedure/ticket-transaction.md>.
```

## Step 4 - Trim the surviving agent definitions

The implementer and reviewer definitions probably reference a leased worktree, a seeded secrets
file, "your first bash command must cd", or the deny hook. Rewrite those to describe working in the
conductor's tree. Keep everything else, especially the repo's review invariants and the "no
commits, no branch switches, no ticket mutations" task contract - which on path (a) is prose-
enforced rather than hook-enforced.

Do NOT keep raw toolchain commands in these files - Step 5 moves them into `.build/config.toml` on
purpose. The surviving agent files should invoke only
`build gate --ticket <ID> --require-checks --json`.

## Step 5 - Consolidate the gate into `build gate`

```sh
git grep -n "npm run\|npm test\|dotnet test\|pytest\|typecheck\|lint" -- '*.md' '.claude/**'
```

In a typical repo the same gate is restated in three or four places: each agent definition plus the
agent doc. Every copy is a drift surface, and when the implementer's gate and the reviewer's gate
differ, the difference surfaces as rework.

Define it ONCE as `[[review.checks]]` in `.build/config.toml` (see
[templates/build-config-snippet.toml](templates/build-config-snippet.toml)), then delete every
prose copy and replace it with `build gate`.

If `.build/config.toml` is intentionally local/ignored, create it before verification. For .NET
repos with `packages.lock.json`, copy or merge
[templates/dotnet-build-config.local.example.toml](templates/dotnet-build-config.local.example.toml),
replace `{{SOLUTION_OR_PROJECT}}`, and keep restore locked plus build/test `--no-restore` so a
new machine does not rewrite package lock files during the gate.

**Then PROVE the gate can fail.** `build gate --ticket TEST-000 --require-checks --json` must
report `checksConfigured: true`. An empty check list exits non-zero with `--require-checks`; without
that flag it exits 0 with `checksConfigured: false` on every ticket forever - a silent pass that
ships everything green. Then deliberately break something, confirm a non-zero exit naming the
failing check, revert, and paste both runs. If the deliberate break or restore changes lock files
or generated files, fix the gate config first; verification should not dirty tracked files.

Never tell a worker to "scope the gate to what you touched." Scope is `--role`, which is
configuration, not judgment.

## Step 6 - Install the ticket transaction

Copy [procedure/ticket-transaction.md](procedure/ticket-transaction.md) into REPO and reference it
from `## Conductor inputs`. It is the authority; do not paraphrase it into the agent doc. What the
repo must declare alongside it:

- the **run branch** (never `main`) and the requirement that the primary worktree is CLEAN before
  any ticket mutation;
- the ticket states that map to In Progress / In Review / Done;
- which ticket states count as a **satisfied dependency**;
- the repo's **finalization invariants** - coordination obligations a gate cannot see (a migration
  whose apply command must be recorded, a contract change whose cross-repo follow-ups must exist).
  Each blocks Done exactly like a red gate.

Do not restate the lifecycle, the rework contract, or the teardown proofs in the agent doc. One
copy.

## Step 7 - Keep what matters

Do NOT remove: the `/run-backlog` command entry point; the implementer and reviewer agent
definitions; `## Conductor inputs` - source roots, branch prefix, deploy/irreversible boundary,
review-model escalation, and above all the **review invariants**.

Those invariants are the real value of the whole apparatus and cannot be derived by any tool. If
you are unsure whether something is machinery or knowledge, it is knowledge - keep it and say so.

## Step 8 - Gate, commit, report

Run `build gate --ticket TEST-000 --require-checks --json` and paste verbatim output. A common
failure here is an orphaned test for a script deleted in Step 3.

Commit on a branch using the repo's branch prefix. Never commit to the primary branch. Do not
merge, push, or deploy - that is a separate explicit human decision.

Report: the Step 2 inventory and what you removed, with line counts; which path the human chose;
how many places the gate had been restated; **both gate runs from Step 5, verbatim**; what you kept
and why; the branch name; anything that did not fit.

## Notes for the agent

- ASCII only in everything you write. Windows plus Git Bash mangles non-ASCII on a curl round trip,
  which has broken Plane updates before.
- Check `git status` before you start. A dirty tree is a stop condition for the conductor loop
  itself; for this one-off cleanup, at minimum stage your own paths explicitly and never sweep
  unrelated changes into your commit.
- If this repo needs its own follow-up ticket, draft it and confirm before creating it.
