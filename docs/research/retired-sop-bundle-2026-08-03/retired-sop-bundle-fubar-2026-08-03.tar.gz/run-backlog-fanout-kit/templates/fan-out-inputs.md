## TEMPLATE: the `Fan-out inputs` block

Paste this into the repo's agent doc (AGENTS.md / CLAUDE.md) under `## Conductor inputs`, and
replace every `{{PLACEHOLDER}}`. Declaring this block is the ACTIVATION switch - a repo without it
stays serial. Delete this heading and these two paragraphs when you paste; keep the bullets.

Most of what used to live here is now in `.build/config.toml` or in the procedure. Do not restate
the gate commands, the seed-file list, the serialization rules, or the lifecycle here - a second
copy is a drift surface, and gate drift is what caused runaway rework. Point at the source.

---

- **Fan-out inputs (OPTIONAL parallelism):** this repo declares build-backed worktree fan-out.
  - **Lifecycle:** {{PATH_TO procedure/ticket-transaction.md}}. It is the single authority for
    ticket states, commit ownership, integration proofs, and teardown safety. **A ticket reaches
    Done only after its conductor commit is integrated, proven an ancestor of the run branch, and
    green under `build gate` on the merged tree.** A per-worktree PASS moves it to In Review.
  - **Scheduling:** {{PATH_TO procedure/fan-out-scheduling.md}}. `[waves].cap` = {{2}}.
  - **Gate:** `build gate --ticket <ID> --require-checks --json` - the only gate command in the
    loop, for every actor at every stage. The toolchain checks are defined once as
    `[[review.checks]]`. **Never restate those commands in prose.**
  - **Review integrity:** the conductor fingerprints the complete candidate before independent
    review and requires exact equality plus a repeated scope check afterwards. Reviewer PASS
    authorizes only that fingerprint, not merely a list of filenames.
  - **Run branch:** {{the integration branch this run commits to, e.g. `{{PREFIX}}-<slug>`}}.
    Never `main`. The primary worktree must be CLEAN before any ticket mutation.
  - **Satisfied-dependency states:** {{e.g. `Done`}}. An external dependency is verified by
    READING it (`build get <DEP> --json`), never by asserting it to `build waves`.
  - **Finalization invariants** - coordination obligations a gate cannot see; each one blocks Done
    exactly like a red gate: {{e.g. a new migration's apply command is recorded on the ticket; a
    contract change has its cross-repo follow-up tickets filed}}.
- **Source roots** (to predict a ticket's files): {{where source lives}}.
- **Review invariants** the reviewer enforces where relevant: {{contract conformance / auth /
  migrations in lockstep with schema / the repo's test bar / etc.}}. These cannot be derived by any
  tool - they are the highest-value line in this block.
- **Ticket CLI** (if not `build`): {{e.g. `linear ...`}} - mirror its mutating verbs into the deny
  hook.
