#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
kit_dir="$(cd "$script_dir/.." && pwd)"
target_repo="${1:-}"
hook="$kit_dir/hooks/deny-worker-git-ticket-ops.sh"

say() {
  printf '\n== %s\n' "$*"
}

need() {
  command -v "$1" >/dev/null 2>&1 || {
    printf 'missing required command: %s\n' "$1" >&2
    exit 2
  }
}

expect_hook_rc() {
  local label="$1"
  local expected="$2"
  local cwd="$3"
  local cmd="$4"
  local output rc

  set +e
  output="$(jq -n \
    --arg cwd "$cwd" \
    --arg cmd "$cmd" \
    '{tool_name:"Bash", cwd:$cwd, tool_input:{command:$cmd}}' \
    | "$hook" 2>&1)"
  rc=$?
  set -e

  if [ "$rc" -ne "$expected" ]; then
    printf 'hook case failed: %s expected rc=%s actual rc=%s\n%s\n' "$label" "$expected" "$rc" "$output" >&2
    exit 1
  fi

  printf 'hook case ok: %s rc=%s\n' "$label" "$rc"
}

run_skill_validator() {
  local validator="$1"
  local skill_dir="$2"
  local py venv vpy

  if [ ! -f "$validator" ]; then
    return 0
  fi

  if command -v python >/dev/null 2>&1; then
    py="$(command -v python)"
  elif command -v python3 >/dev/null 2>&1; then
    py="$(command -v python3)"
  else
    printf 'python not found; skipping optional skill quick_validate.py\n'
    return 0
  fi

  if "$py" - <<'PY' >/dev/null 2>&1
import yaml
PY
  then
    "$py" "$validator" "$skill_dir"
    return
  fi

  printf 'python lacks PyYAML; creating temporary validator venv\n'
  venv="$(mktemp -d "${TMPDIR:-/tmp}/run-backlog-kit-validator.XXXXXX")"
  (
    trap 'rm -rf "$venv"' EXIT
    "$py" -m venv "$venv"
    if [ -x "$venv/Scripts/python.exe" ]; then
      vpy="$venv/Scripts/python.exe"
    else
      vpy="$venv/bin/python"
    fi
    PIP_DISABLE_PIP_VERSION_CHECK=1 "$vpy" -m pip install --quiet PyYAML
    "$vpy" "$validator" "$skill_dir"
  ) || {
    printf 'skill validation needs PyYAML. Install it for your Python or rerun with network access for the temporary venv.\n' >&2
    exit 2
  }
}

smoke_package_script() {
  local tmp copied out archive tar_list

  tmp="$(mktemp -d "${TMPDIR:-/tmp}/run-backlog-kit-package-smoke.XXXXXX")"
  (
    trap 'rm -rf "$tmp"' EXIT
    copied="$tmp/renamed-kit"
    out="$tmp/out"
    cp -a "$kit_dir" "$copied"
    mkdir -p "$out"

    "$copied/scripts/package-kit.sh" "$out" >/dev/null
    archive="$(find "$out" -maxdepth 1 -type f -name 'run-backlog-fanout-kit-*.tar.gz' | sort | tail -n 1)"
    test -n "$archive"
    tar_list="$tmp/archive-list.txt"
    tar -tzf "$archive" > "$tar_list"

    grep -qx 'run-backlog-fanout-kit/README.md' "$tar_list"
    grep -qx 'run-backlog-fanout-kit/templates/dotnet-build-config.local.example.toml' "$tar_list"
    if grep -q '^run-backlog-fanout-kit/.dist/' "$tar_list"; then
      printf 'package includes .dist; archive would carry stale archives\n' >&2
      exit 1
    fi
  )
}

say "tool contracts"
need build
need git
need jq
build --version
build worktree --help >/dev/null
build gate --help >/dev/null
build waves --help >/dev/null
build help config | grep -F 'standalone deterministic commands' >/dev/null
bash -n "$hook"
bash -n "$kit_dir/scripts/install-run-backlog-skill.sh"
bash -n "$kit_dir/scripts/package-kit.sh"

say "portable skill source"
skill_dir="$kit_dir/skills/run-backlog"
test -f "$skill_dir/SKILL.md"
test -f "$skill_dir/agents/openai.yaml"
test -f "$skill_dir/references/agent-contracts.md"
test -f "$skill_dir/references/parallel-fan-out.md"
test -f "$skill_dir/references/repo-adaptation.md"
test -f "$skill_dir/references/serial-loop.md"
grep -q '^name: run-backlog$' "$skill_dir/SKILL.md"
grep -q 'references/serial-loop.md' "$skill_dir/SKILL.md"
grep -q 'references/parallel-fan-out.md' "$skill_dir/SKILL.md"
grep -q 'references/repo-adaptation.md' "$skill_dir/SKILL.md"
grep -q 'references/agent-contracts.md' "$skill_dir/SKILL.md"
if grep -R -n -P '[^\x00-\x7F]' "$skill_dir"; then
  printf 'non-ASCII found in portable skill source\n' >&2
  exit 1
fi
validator="${CODEX_HOME:-$HOME/.codex}/skills/.system/skill-creator/scripts/quick_validate.py"
run_skill_validator "$validator" "$skill_dir"
printf 'portable skill source ok\n'

say "package smoke"
smoke_package_script
printf 'package smoke ok\n'

say "stale installable text scan"
stale_pattern='verified_external_deps|global_serial_prefixes|shared_prefixes|module_roots|build help (gate|worktree|waves)|TLB-594 removes|validates the WHOLE file|parses and validates the entire file|build worktree teardown --ticket <ID>$'
scan_paths=(
  "$kit_dir/README.md"
  "$kit_dir/migrate-from-hand-rolled.md"
  "$kit_dir/procedure"
  "$kit_dir/templates"
  "$kit_dir/hooks"
  "$kit_dir/skills/run-backlog"
)
if command -v rg >/dev/null 2>&1; then
  if rg -n "$stale_pattern" "${scan_paths[@]}"; then
    printf 'stale installable text found; update the matches above\n' >&2
    exit 1
  fi
else
  if grep -R -n -E "$stale_pattern" "${scan_paths[@]}"; then
    printf 'stale installable text found; update the matches above\n' >&2
    exit 1
  fi
fi
printf 'stale scan ok\n'

if [ -z "$target_repo" ]; then
  printf '\nNo target repo supplied; skipped repo smoke tests.\n'
  printf 'Run: %s /path/to/repo\n' "$0"
  exit 0
fi

say "target repo"
repo_root="$(git -C "$target_repo" rev-parse --show-toplevel)"
cd "$repo_root"
printf 'repo: %s\n' "$repo_root"

if [ ! -f ".build/config.toml" ]; then
  printf 'target repo has no .build/config.toml; cannot run build-backed smoke tests\n' >&2
  printf 'create one by merging %s/templates/build-config-snippet.toml into the repo config\n' "$kit_dir" >&2
  printf 'for .NET repos with package locks, %s/templates/dotnet-build-config.local.example.toml is a non-mutating starter\n' "$kit_dir" >&2
  exit 2
fi

run_ref="$(git branch --show-current)"
if [ -z "$run_ref" ]; then
  run_ref="HEAD"
fi
printf 'run ref: %s\n' "$run_ref"

say "waves smoke"
build waves --input - --json <<'JSON' | jq -e '.ok == true' >/dev/null
[
  {"id":"TEST-1","files":["src/a.txt"],"deps":[]},
  {"id":"TEST-2","files":["src/b.txt"],"deps":[]},
  {"id":"TEST-3","files":["src/a.txt"],"deps":[]}
]
JSON
printf 'waves smoke ok\n'

say "gate smoke"
build gate --ticket TEST-KIT --require-checks --json | jq -e '.ok == true and .data.checksConfigured == true and .data.passed == true' >/dev/null
printf 'gate smoke ok\n'

say "worktree and hook smoke"
ticket="TEST-KIT-VERIFY"
leased=0
cleanup() {
  if [ "$leased" -eq 1 ]; then
    build worktree teardown --ticket "$ticket" --require-merged-into "$run_ref" --json >/dev/null 2>&1 || true
  fi
}
trap cleanup EXIT

build worktree list --json | jq -e '.ok == true' >/dev/null
lease_json="$(build worktree lease --ticket "$ticket" --slug kit-smoke --base "$run_ref" --json)"
leased=1
printf '%s\n' "$lease_json" | jq -e '.ok == true and (.data.path | length > 0) and (.data.manifest.branch | length > 0) and (.data.manifest.baseSha | length > 0)' >/dev/null
lease_path="$(printf '%s\n' "$lease_json" | jq -r '.data.path')"
git_path="$(command -v git)"
build_path="$(command -v build)"

expect_hook_rc "linked plain commit" 2 "$lease_path" "git commit --allow-empty -m probe"
expect_hook_rc "linked git -C commit" 2 "$lease_path" "git -C \"$lease_path\" commit --allow-empty -m probe"
expect_hook_rc "linked git -c commit" 2 "$lease_path" "git -c user.name=Probe commit --allow-empty -m probe"
expect_hook_rc "linked absolute git commit" 2 "$lease_path" "\"$git_path\" commit --allow-empty -m probe"
expect_hook_rc "linked build transition" 2 "$lease_path" "build transition $ticket Done"
expect_hook_rc "linked build worktree teardown" 2 "$lease_path" "build worktree teardown --ticket $ticket"
expect_hook_rc "linked build gate" 0 "$lease_path" "build gate --ticket $ticket --require-checks --json"
expect_hook_rc "linked absolute build transition" 2 "$lease_path" "\"$build_path\" transition $ticket Done"
expect_hook_rc "primary conductor git -C commit" 0 "$repo_root" "git -C \"$lease_path\" commit --allow-empty --dry-run -m probe"

build worktree teardown --ticket "$ticket" --require-merged-into "$run_ref" --json | jq -e '.ok == true' >/dev/null
leased=0
build worktree list --json | jq -e '.ok == true and (.data.leases | length == 0)' >/dev/null
printf 'worktree and hook smoke ok\n'
