#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
kit_dir="$(cd "$script_dir/.." && pwd)"
out_dir="${1:-$kit_dir/.dist}"
stamp="$(date +%Y%m%d-%H%M%S)"
archive="$out_dir/run-backlog-fanout-kit-$stamp.tar.gz"
tmp_dir=""

cleanup() {
  if [ -n "$tmp_dir" ] && [ -d "$tmp_dir" ]; then
    rm -rf "$tmp_dir"
  fi
}
trap cleanup EXIT

mkdir -p "$out_dir"
out_dir="$(cd "$out_dir" && pwd)"
archive="$out_dir/run-backlog-fanout-kit-$stamp.tar.gz"

tmp_dir="$(mktemp -d "${TMPDIR:-/tmp}/run-backlog-kit-package.XXXXXX")"
stage="$tmp_dir/run-backlog-fanout-kit"

cp -a "$kit_dir" "$stage"
rm -rf "$stage/.dist" "$stage/.git"

tar -czf "$archive" -C "$tmp_dir" "run-backlog-fanout-kit"

printf 'Created %s\n' "$archive"
