#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
kit_dir="$(cd "$script_dir/.." && pwd)"
src="$kit_dir/skills/run-backlog"
codex_home="${CODEX_HOME:-$HOME/.codex}"
dest_parent="$codex_home/skills"
dest="$dest_parent/run-backlog"

say() {
  printf '%s\n' "$*"
}

fail() {
  printf 'install-run-backlog-skill: %s\n' "$*" >&2
  exit 1
}

fallback_validate() {
  grep -q '^name: run-backlog$' "$1/SKILL.md"
  grep -q '^description:' "$1/SKILL.md"
}

run_skill_validator() {
  local validator="$1"
  local skill_dir="$2"
  local py

  if [ ! -f "$validator" ]; then
    fallback_validate "$skill_dir"
    return
  fi

  if command -v python >/dev/null 2>&1; then
    py="$(command -v python)"
  elif command -v python3 >/dev/null 2>&1; then
    py="$(command -v python3)"
  else
    say "python not found; using lightweight skill validation"
    fallback_validate "$skill_dir"
    return
  fi

  if "$py" - <<'PY' >/dev/null 2>&1
import yaml
PY
  then
    "$py" "$validator" "$skill_dir"
  else
    say "python lacks PyYAML; using lightweight skill validation"
    fallback_validate "$skill_dir"
  fi
}

test -f "$src/SKILL.md" || fail "missing source skill: $src/SKILL.md"
test -f "$src/agents/openai.yaml" || fail "missing source skill metadata"
test -f "$src/references/agent-contracts.md" || fail "missing agent contracts reference"
test -f "$src/references/parallel-fan-out.md" || fail "missing fan-out reference"
test -f "$src/references/repo-adaptation.md" || fail "missing adaptation reference"
test -f "$src/references/serial-loop.md" || fail "missing serial-loop reference"

mkdir -p "$dest_parent"

if [ -L "$dest" ]; then
  fail "refusing to replace symlink: $dest"
fi

if [ -e "$dest" ]; then
  stamp="$(date +%Y%m%d-%H%M%S)"
  backup="$dest.backup-$stamp"
  say "Backing up existing skill to: $backup"
  mv "$dest" "$backup"
fi

cp -a "$src" "$dest"

validator="$codex_home/skills/.system/skill-creator/scripts/quick_validate.py"
run_skill_validator "$validator" "$dest"

say "Installed run-backlog skill to: $dest"
