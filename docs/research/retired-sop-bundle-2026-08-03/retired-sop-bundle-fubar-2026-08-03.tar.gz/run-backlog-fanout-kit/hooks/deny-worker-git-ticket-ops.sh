#!/usr/bin/env bash
set -uo pipefail

# Deny run-backlog WORKER-forbidden operations when the Bash call runs inside a LINKED git
# worktree (a worker's leased tree): history writes, branch/remote operations, work-destroying
# git verbs, ticket mutations, delivery, and workspace lifecycle.
#
# The conductor runs in the PRIMARY worktree and is unaffected, so it can still commit, transition
# tickets, and lease/tear down worktrees as the procedure requires. That is also why the procedure
# has the conductor commit into a lease with `git -C <lease> commit` FROM the primary tree rather
# than by cd-ing in: cd-ing in makes the conductor indistinguishable from a worker, and this hook
# would - correctly - deny it.
#
# Detection: in the primary worktree, `git rev-parse --git-dir` and `--git-common-dir` resolve to
# the same path; in a linked worktree they differ. That is the only reliable, cross-platform
# worker-vs-conductor signal. The directory probed is the command's EFFECTIVE directory: a leading
# `cd <dir> &&` / `cd <dir>;` prefix wins over the session cwd, because a worker told to "cd to
# your worktree first" otherwise reports the session's cwd and evades detection entirely.
#
# Command matching intentionally catches common Bash forms including chained commands, quoted or
# absolute `git` / `git.exe` / `build` / `build.exe` paths, and Git global options such as `-C`,
# `-c`, `--git-dir`, and `--work-tree` before the subcommand. It is still a hook, not a shell
# sandbox; the conductor must inspect worker state after every worker returns.
#
# KNOWN LIMIT, stated rather than papered over: a worker whose session directory is the primary
# tree and which never cd's is indistinguishable from the conductor. Workers MUST be launched with
# the lease as their working directory. This hook is defense in depth, not the contract.
#
# INERT until the conductor leases worktrees: in a shared tree there is exactly one actor and no
# linked worktree to key on, so this hook returns 0 and never fires. Safe to install before
# fan-out is switched on.
#
# Fail-open by design: if jq or git is absent, or the plumbing errors, the hook allows the call
# rather than blocking legitimate work.

command -v jq  >/dev/null 2>&1 || exit 0
command -v git >/dev/null 2>&1 || exit 0

input_json="$(cat)"

tool_name="$(printf '%s' "$input_json" | jq -r '.tool_name // ""' 2>/dev/null || echo "")"
[ "$tool_name" = "Bash" ] || exit 0

command_text="$(printf '%s' "$input_json" | jq -r '.tool_input.command // ""' 2>/dev/null || echo "")"
cwd="$(printf '%s' "$input_json" | jq -r '.cwd // "."' 2>/dev/null || echo ".")"

# Normalize whitespace for matching.
cmd="$(printf '%s' "$command_text" | tr '\n\t' '  ')"

# Effective directory: honor a leading `cd <dir>` prefix (quoted or bare) if the path exists.
probe_dir="$cwd"
if [[ "$cmd" =~ ^[[:space:]]*cd[[:space:]]+\"([^\"]+)\" ]] \
   || [[ "$cmd" =~ ^[[:space:]]*cd[[:space:]]+\'([^\']+)\' ]] \
   || [[ "$cmd" =~ ^[[:space:]]*cd[[:space:]]+([^[:space:];\&\|]+) ]]; then
  candidate="${BASH_REMATCH[1]}"
  [ -d "$candidate" ] && probe_dir="$candidate"
fi

git_dir="$(git -C "$probe_dir" rev-parse --path-format=absolute --git-dir 2>/dev/null || true)"
common_dir="$(git -C "$probe_dir" rev-parse --path-format=absolute --git-common-dir 2>/dev/null || true)"

# Not a git dir, plumbing failed, or the PRIMARY worktree (conductor) -> allow.
if [ -z "$git_dir" ] || [ -z "$common_dir" ] || [ "$git_dir" = "$common_dir" ]; then
  exit 0
fi

# Worker context (linked worktree). Exit 2 with a stderr message is the blocking form: the message
# is fed back to the calling agent, which is exactly the correction we want it to read.
deny() {
  printf 'run-backlog worker: %s (Blocked in a linked worktree.)\n' "$1" >&2
  exit 2
}

boundary='(^|[[:space:];&|()])'
cmd_end='([[:space:];&|()]|$)'
git_exe='(git|git\.exe|"[^"]*[/\\]git(\.exe)?"|[^[:space:];&|()]+[/\\]git(\.exe)?)'
build_exe='(build|build\.exe|"[^"]*[/\\]build(\.exe)?"|[^[:space:];&|()]+[/\\]build(\.exe)?)'
shell_arg='("[^"]*"|'\''[^'\'']*'\''|[^[:space:];&|()]+)'
git_global='([[:space:]]+(-C|--git-dir|--work-tree|-c|--config-env)[[:space:]]+('"$shell_arg"')|[[:space:]]+--no-pager|[[:space:]]+-[[:alpha:]]+)'

git_subcommand_re() {
  local verbs="$1"
  [[ "$cmd" =~ $boundary$git_exe($git_global)*[[:space:]]+($verbs)$cmd_end ]]
}

build_subcommand_re() {
  local verbs="$1"
  [[ "$cmd" =~ $boundary$build_exe[[:space:]]+($verbs)$cmd_end ]]
}

build_worktree_re() {
  local verbs="$1"
  [[ "$cmd" =~ $boundary$build_exe[[:space:]]+worktree[[:space:]]+($verbs)$cmd_end ]]
}

# 1) History writes. The conductor creates the ticket commit, after an independent review PASS.
if git_subcommand_re 'commit|am|revert|cherry-pick|rebase|merge'; then
  deny "workers do not write git history. Report your diff and verbatim gate output to the conductor; the conductor stages the approved paths, commits, and integrates."
fi

# 2) Branch, remote, and worktree-topology operations.
if git_subcommand_re 'switch|push|pull|fetch|branch|worktree|tag|checkout'; then
  deny "workers do not switch branches, move refs, or touch remotes. Stay on your leased worktree and report to the conductor."
fi

# 3) Work-destroying verbs. These are what turn a recoverable failure into a lost one.
if git_subcommand_re 'stash|clean|restore|reset'; then
  deny "workers do not discard work. If a change is wrong, undo it by editing; the conductor needs the tree to reflect what you actually did."
fi

# 4) Ticket mutations, delivery, and worker-spawning verbs via the build CLI.
# Reads stay allowed on purpose: `build get`, `list`, `comments`, `waves`, `worktree list`, and
# above all `build gate` - the worker MUST be able to run its gate.
# ADAPT: if this repo's tickets live somewhere else (Linear, Jira, gh), add that CLI's mutating
# verbs here as an additional rule. Leave rules (1) to (3) alone.
build_denied='transition|new|comment|amend|close|defer|reopen|relate|setup|init|scaffold'
build_denied="$build_denied|ship|chain|plan|implement|review|decompose|rework|sweep"
if build_subcommand_re "$build_denied"; then
  deny "workers do not mutate tickets, ship, or spawn workers. Return findings to the conductor; the conductor owns all ticket state and delivery."
fi

# 5) Workspace lifecycle is the conductor's. `build worktree list` is a read - allow it.
if build_worktree_re 'lease|teardown'; then
  deny "the conductor owns the worktree lifecycle. Do not lease or tear down worktrees - you are already in yours."
fi

exit 0
