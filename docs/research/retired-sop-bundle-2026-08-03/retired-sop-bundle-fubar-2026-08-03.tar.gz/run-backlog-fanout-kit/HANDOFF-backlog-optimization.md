# HANDOFF: backlog workflow optimization follow-ups

This file is background only. Do not install it into target repositories.

The transcript benchmark from the instruction-compaction work showed that static instruction
compaction saves context, but the larger remaining cost is workflow ceremony repeated at run time.
These follow-ups belong in Throughline Build and the run-backlog workflow.

## Candidate commands

### `build candidate status --json`

Report base SHA, HEAD SHA, tracked diff hash, cached/index diff hash, untracked file-list hash,
touched paths, and lease metadata. The command must not mutate tickets, commits, branches, remotes,
integration state, or worktree lifecycle.

### `build evidence add`

Format claim, review, commit, integrate, gate, and final evidence comments consistently. Each
invocation should still be an explicit ticket mutation with readback. It must not combine lifecycle
transitions or cascade to related tickets.

### `build worker brief`

Generate a compact role-specific brief for implementers and reviewers. The brief should include the
ticket body/comments, acceptance criteria, declared surface, exact gate, role contract, mutation
bans, response format, and contract version/hash. It should not spawn workers.

### `build run summarize`

Optional read-only final summary command for ticket state, commits, review/rework count, gates,
leases, cleanup, and working-tree status.

## Safety behaviors to preserve

- Baseline gate before claim.
- Ticket access through the declared ticket client only.
- Leased worktree isolation.
- Implementer/reviewer split and fresh reviewer after rework.
- Strong review for contract, migration, persistence, auth, publication, and irreversible behavior.
- Candidate fingerprint before and after review.
- Commit only after review passes and the fingerprint holds.
- Rebase/fast-forward integration with ancestry proof.
- Merged-tree gate before Done.
- Explicit ticket evidence, transitions, and readback.
- Safe Build worktree teardown.
- No push, deploy, remote mutation, migration application, or merge to the primary branch without
  explicit authorization.

## Suggested ticket order

1. Add candidate status/fingerprint command.
2. Adopt candidate status in run-backlog guidance.
3. Add worker brief artifact command.
4. Adopt worker briefs in worker handoffs.
5. Add structured evidence comments.
6. Adopt structured evidence in run-backlog.
7. Investigate risk-tiered gate policy without reducing gates.
8. Benchmark the improved workflow against the original transcript shape.
