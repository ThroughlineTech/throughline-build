# HANDOFF: Throughline Build assumptions audit

This file is background only. Do not copy it into target repositories.

The installer kit used to carry compensating instructions for missing Build behavior. Those
compensations are no longer part of the installable path. The current kit assumes the installed
`build` binary supports these contracts:

1. `build gate --require-checks` fails when no selected `[[review.checks]]` are configured.
2. `build worktree teardown --require-merged-into <ref>` proves the helper branch is integrated
   before deleting a lease.
3. `build worktree`, `build gate`, and `build waves` use section-scoped config loading and do not
   require `[ticketing]`, `[workers]`, or `[events]`.

Verify on each machine with:

```sh
build --version
build worktree --help
build gate --help
build waves --help
build help config
```

`build <command> --help` is the canonical command contract. `build help config` is reference prose
for config behavior only.

The remaining useful Build improvements are:

1. A conductor-side commit verb that stages explicit reviewed paths on a lease branch and returns
   the SHA while preserving/recovering the index on failure.
2. A sanitized worker-local config written into each lease, with support for lease roots outside the
   primary repository. Section-scoped loading is not a filesystem security boundary.

For kit parity and smoke testing, run:

```sh
scripts/verify-kit.sh /path/to/target-repo
```

That verifier uses fake ticket IDs only. It checks the Build command contracts, scans installable
kit files for stale schema/help text, runs `build waves`, runs the target repo's configured
`build gate --ticket TEST-KIT --require-checks --json`, leases a throwaway worktree, exercises the
Claude hook, and tears the lease down with `--require-merged-into`.
