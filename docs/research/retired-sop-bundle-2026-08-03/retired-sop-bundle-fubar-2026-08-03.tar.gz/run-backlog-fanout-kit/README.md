# run-backlog fan-out - portable source kit

You are an AGENT. Someone pointed you at this kit. Your job is one of:

- install/update the portable `run-backlog` Codex skill on this machine;
- install and adapt the build-backed run-backlog ticket transaction, and optionally its fan-out
  scheduling layer, into a target repository;
- package the kit for another machine.

## Two directories - do not confuse them

- **KIT_DIR** - the directory this README is in. Everything written as `templates/...`,
  `hooks/...`, `procedure/...`, `skills/...` is relative to KIT_DIR. READ-ONLY source material
  when installing into a target repo. If the kit is wrong, say so in your report; do not edit it
  while installing.
- **REPO** - the target repository, normally your cwd. Everything written as `.claude/...`,
  `.build/...`, `AGENTS.md` is relative to REPO. The only place you write.

Establish both before Step 0 and state them in your report. If REPO is not your cwd, or
`git -C <REPO> rev-parse --show-toplevel` fails, STOP and ask.

## Machine setup

For Codex, install or update the portable skill from this kit:

```sh
bash "$KIT_DIR/scripts/install-run-backlog-skill.sh"
```

That copies `skills/run-backlog` into `${CODEX_HOME:-$HOME/.codex}/skills/run-backlog`, backing up
an existing installed copy first. Validate the kit itself with:

```sh
bash "$KIT_DIR/scripts/verify-kit.sh"
```

To move this kit to another machine:

```sh
bash "$KIT_DIR/scripts/package-kit.sh"
```

Copy the generated `.dist/run-backlog-fanout-kit-*.tar.gz`, unpack it on the destination machine,
then run `scripts/install-run-backlog-skill.sh` there. Re-run the package script after every kit
change; the archive is the transport unit.

## Route first for target repositories

```sh
# in REPO:
git grep -ln "run-backlog\|Conductor inputs" -- '*.md' | head
ls scripts/backlog-worktree.mjs scripts/backlog-preflight.mjs 2>/dev/null
ls .claude/agents/ 2>/dev/null
```

| What you found | Situation | What to do |
| --- | --- | --- |
| Nothing - no run-backlog anywhere | **A. Fresh install** | Skip Step 0. Do Steps 1-8. |
| `backlog-worktree.mjs` / `backlog-preflight.mjs` / an integrator agent | **B. Old hand-rolled kit** | Step 0 first, then Steps 1-8. |
| run-backlog present, and the human wants it SERIAL | **C. Simplify to serial** | Use [migrate-from-hand-rolled.md](migrate-from-hand-rolled.md) instead. |

Situation C is a real and often correct answer: fan-out only pays on genuinely file-disjoint
tickets. **If you find situation B, ask the human whether they want B or C before removing
anything** - the removal is the same, the destination is not.

Note that the ticket transaction in `procedure/ticket-transaction.md` applies to serial runs too.
Situation C removes the SCHEDULING layer, not the lifecycle.

Adapt every ADAPT point to the target repo. If a step becomes unsafe or ambiguous, STOP and ask.

## The model

A conductor drives the backlog. For each ticket it runs one transaction: lease a worktree,
baseline the gate, claim the ticket, dispatch an implementer, check scope, dispatch an INDEPENDENT
reviewer, then - itself, in the primary tree - commit the approved paths, integrate the commit onto
the run branch, prove the commit is an ancestor of the integration HEAD, re-gate the merged tree,
and only then mark the ticket Done and tear the lease down.

Fan-out changes only how many of those transactions are in flight at once. It changes no rule.

Two invariants everything serves:

1. **A ticket is Done only when the run branch provably contains its verified change.**
2. **Nothing is deleted while it might still hold unintegrated work.**

Deterministic work is delegated to the `build` CLI: `build worktree` for workspace lifecycle,
`build waves` for scheduling, `build gate --require-checks` for what "green" means. The conductor
hand-rolls none of those three primitives. It still performs the explicit-path commit and the
serial integration steps described by the transaction. Fan-out pays off ONLY on genuinely
file-disjoint tickets - roughly 2x net on a good batch, not across the board.

## What is in this kit

```
README.md                              <- you are here: entry point for situations A and B
migrate-from-hand-rolled.md            <- entry point for situation C (remove machinery, go serial)
skills/run-backlog/                    <- portable Codex skill source
scripts/install-run-backlog-skill.sh   <- installs the skill into CODEX_HOME
scripts/package-kit.sh                 <- creates a tarball for another machine
procedure/instruction-compaction.md    <- behavior-preserving instruction compaction workflow
procedure/ticket-transaction.md        <- THE lifecycle: states, proofs, failures, recovery (UNIVERSAL)
procedure/fan-out-scheduling.md        <- the scheduling layer only (UNIVERSAL)
templates/build-config-snippet.toml    <- the .build/config.toml sections (THE MAIN PORT)
templates/dotnet-build-config.local.example.toml
                                       <- local non-mutating starter for .NET repos with package locks
templates/fan-out-inputs.md            <- the block you paste into the repo's Conductor inputs
hooks/deny-worker-git-ticket-ops.sh    <- blocks worker git-history/ticket ops (host-specific)
templates/settings-hook-snippet.json   <- how to wire that hook into .claude/settings.json
templates/agents/*.md                  <- thin implementer / reviewer definitions (host-specific)

HANDOFF-build-followups-audit.md       <- NOT INSTALLED. Audit brief for the Throughline Build
                                          follow-ups this kit depends on. Do not copy into a repo.
HANDOFF-backlog-optimization.md        <- NOT INSTALLED. Candidate Build helper commands from
                                          transcript benchmarking. Do not copy into a repo.
```

## The three layers - keep them clean

| Layer | Files | What changes per repo |
| --- | --- | --- |
| **Universal transaction** | `procedure/*.md`, `build worktree\|gate\|waves` | nothing |
| **Codex skill** | `skills/run-backlog/**` | installed per machine, not per repo |
| **Host adapter** | `templates/agents/*.md`, `hooks/*.sh`, `templates/settings-hook-snippet.json` | swap wholesale for a non-Claude harness |
| **Repo configuration** | `[[review.checks]]`, `[worktree]`, `[waves]`, review + finalization invariants, run branch | all of it |

The host adapter is the only Claude-specific part. A different harness replaces two mechanisms -
how a subagent is defined, how a pre-tool hook is registered - and keeps everything above
unchanged. Do not let host details leak into the procedure or the config.

## Prerequisites

`build` (Throughline Build) on `PATH`, new enough to have the three verbs:

```sh
build worktree --help && build gate --help && build waves --help
```

If any is an unknown verb, stop: the host machine's `build` predates this kit.

`worktree`, `gate`, and `waves` are standalone deterministic commands. Current Build loads only the
sections those commands consume, so **a repo whose tickets live in Linear, Jira, GitHub Issues, or
another system can use this kit**: the conductor uses that repo's own ticket CLI for ticket state,
and `build` for worktrees, gates, and wave planning.

That section scoping is config validation behavior, not a credential boundary. A worker in a nested
lease can still read the parent repository's `.build/config.toml` as a file. Keep secrets in
environment variables instead of inline TOML values.

## Install steps (in order)

### 0. Situation B only - remove the OLD kit first

Skip on a fresh install. Do not layer the new kit on the old one.

```sh
ls scripts/backlog-worktree.mjs scripts/backlog-preflight.mjs 2>/dev/null
ls .claude/agents/backlog-integrator.md 2>/dev/null
git grep -ln "backlog-worktree\|backlog-preflight\|backlog-integrator"
```

Remove those scripts, any test file covering them (easy to miss - it will fail the gate if left
behind), the integrator agent definition, the old `Fan-out inputs` block, and any gitignore entry
for the old worktree root. Report the line counts. Keep an already-installed deny hook; Step 4
updates it in place.

### 1. Learn this repo

Answer: what are the GATE commands? What does a fresh checkout need before those can run (install,
codegen)? What LOCAL gitignored files does a worker need to actually run? What would two parallel
gate runs collide on (fixed ports, a shared local DB, a device)? What is the ticket system and CLI,
and which ticket states count as satisfied for a dependency? Where does source live, so you can
predict a ticket's files? What coordination obligations exist that a gate cannot see (migrations to
apply, a contract's cross-repo follow-ups)? That last one becomes the finalization invariants.

### 2. Configure build - THIS IS THE MAIN PORT

Merge `templates/build-config-snippet.toml` into `REPO/.build/config.toml`, filling every
`{{PLACEHOLDER}}`. Four things to get right:

- `[[review.checks]]` - the repo's real gate. At least one `gating` check is MANDATORY.
- `[project].install_command` - what a fresh worktree runs.
- `[worktree].seed_files` - the untracked local files a worker needs. Must be untracked, relative,
  and free of `.` / `..` segments; build refuses anything else by name. You do NOT need
  `.build/config.toml` here: `build` finds config by walking up parent directories, so a lease
  under the default (nested) root resolves it from the primary tree. Keep `[worktree].root` inside
  the primary tree for that reason.
- `[waves]` - the cap, plus this repo's serialization rules. Exact-file overlap serializes
  automatically; these rules add the conflict classes only a human knows (lockfiles and migrations
  as `global`, coupled directories as `cohesive-module`, a contract and its consumers as
  `pairwise`).

Add `[worktree].root` (default `.worktrees/conductor`) to `.gitignore`.

If the kit was copied to a new machine and the target repo intentionally keeps `.build/config.toml`
ignored, create a local config before running the verifier. For .NET repos with `packages.lock.json`,
start from `templates/dotnet-build-config.local.example.toml`: replace `{{SOLUTION_OR_PROJECT}}`,
copy or merge it into `REPO/.build/config.toml`, and keep restore locked plus build/test
`--no-restore` so the gate does not rewrite package locks because this machine has a newer SDK.

If a gate check would collide with a concurrent copy of itself on a fixed resource, fix it here -
make the check derive its resource per-worktree, or set `[waves].cap = 1`. Do NOT solve it by
telling workers to run a narrower gate.

### 3. PROVE the gate can fail

**Do not skip this.** A `[[review.checks]]` list with no entries makes `build gate` exit 0 with
`"checksConfigured": false` on every ticket forever. Verified in the source: with zero selected
checks the result set is empty and `passed` is the vacuous `all()` of nothing. Every ticket ships
green, the reviewer becomes the only real gate, and rework turns subjective. This has escaped into
production before.

```sh
build gate --ticket TEST-000 --require-checks --json
# expect: "checksConfigured": true, "passed": true
```

Then prove the failure path: break something deliberately (a syntax error in a file the gate
compiles, or a failing assertion), re-run, confirm a non-zero exit naming the failing check, and
revert. Paste both runs in your report. A gate that has never been observed failing is not a gate.
If the deliberate break changes lock files or generated files, the gate is not machine-portable yet:
switch restore/build/test to the locked/no-restore pattern before continuing.

### 4. Install the deny hook (host-specific)

- Copy `hooks/deny-worker-git-ticket-ops.sh` -> `REPO/.claude/hooks/`.
- Wire it into `REPO/.claude/settings.json` as a PreToolUse[Bash] hook per
  `templates/settings-hook-snippet.json`. MERGE it; do not clobber existing hooks.
- Confirm `jq` and `git` are on PATH. The hook intentionally fails open when either is missing, so
  a host without `jq` has prose enforcement only until that is fixed.
- ADAPT rule (4) only if this repo's tickets are not in `build` - add that CLI's mutating verbs.
  Leave rules (1)-(3) alone. Confirm `build gate` stays ALLOWED: workers must run their own gate.
- The hook is inert until worktrees exist, so it is safe to install before switching fan-out on.
- On a host without pre-tool hooks, skip this step. The same limits are stated in the agent
  definitions as prose; enforcement is weaker, the contract is identical.

### 5. Install the agent definitions

Copy `templates/agents/*.md` -> `REPO/.claude/agents/`. Replace `{{REPO_NAME}}`.

**Fill in the reviewer's "Review invariants" section with this repo's real invariants** - contract
conformance, auth gates, response envelopes, migrations shipping in lockstep with their schema and
types, the test bar for a UI surface. No tool can derive these, and they are the difference between
a reviewer that catches real defects and one that argues about naming.

KEEP: the reviewer has NO Edit/Write tool (that is the point). Do NOT add gate commands to either
file - `build gate` is the gate, and a prose copy is the drift that caused rework loops.

Some hosts do not resolve `.claude/agents/*` as spawnable types. Where they do not, the conductor
spawns a general-purpose agent and pastes the definition body inline. The roles are identical.

### 6. Declare the opt-in

Paste `templates/fan-out-inputs.md` into REPO's agent doc under `## Conductor inputs` and fill in
the placeholders. Copy `procedure/ticket-transaction.md` and `procedure/fan-out-scheduling.md` into
REPO (or point at them where they live) and reference both from the block.

IMPORTANT: declaring this block is the ACTIVATION switch. A repo with no Fan-out inputs block stays
serial. Only add it when the human wants fan-out on.

### 7. Verify (do NOT touch real tickets)

```sh
# waves: two tickets sharing a file must serialize; a disjoint one may pair
echo '[{"id":"X-1","files":["<real path A>"],"deps":[]},
       {"id":"X-2","files":["<real path B>"],"deps":[]},
       {"id":"X-3","files":["<real path A>"],"deps":[]}]' > waves.json
build waves --input waves.json
#  -> "exact-file: both tickets predict the exact file ..." and X-3 in its own wave
# ALSO prove one rule YOU configured fires - feed it two tickets that should serialize under your
# global / cohesive-module / pairwise rule and read the printed reason.

# lease a throwaway worktree
build worktree lease --ticket TEST-000 --slug smoke --json
#  -> ok:true, data.path, data.manifest.branch, data.manifest.baseSha, seededFiles, install status.
#     A TRACKED path in seed_files is refused here by name.
build worktree list --json

# in that worktree: seeds present, install ran, gate green
cd <printed path> && ls -a && build gate --ticket TEST-000 --require-checks --json
#  -> checksConfigured:true, passed:true. Config resolves from the primary tree.

# the hook blocks worker git-history ops HERE but not in the primary tree
git commit --allow-empty -m probe                 # expect DENIED in the worktree
git -C <lease path> commit --allow-empty -m probe  # expect DENIED even with Git -C
git stash list                                    # expect DENIED (work-destroying verb family)
build transition TEST-000 Done                    # expect DENIED
build gate --ticket TEST-000 --require-checks --json # expect ALLOWED

# the conductor's commit path is not blocked when called from the PRIMARY tree.
# --dry-run is REQUIRED here: this verifies hook routing without creating an unmerged probe commit.
cd <primary tree>
git -C <lease path> commit --allow-empty --dry-run -m probe   # expect not denied; creates nothing

# smoke-lease teardown proofs. This lease has no ticket mutation and MUST still be untouched:
# HEAD == baseSha proves there is no conductor commit to lose; baseSha is already in primary HEAD.
git -C <lease path> rev-parse HEAD                            # MUST equal manifest baseSha
git -C <primary tree> merge-base --is-ancestor <baseSha> HEAD # expect exit 0
git -C <lease path> status --porcelain                       # expect empty
git -C <lease path> ls-files --others --exclude-standard     # expect only the lease manifest + seeds
build worktree teardown --ticket TEST-000 --require-merged-into <primary branch> --json
build worktree list                    # expect no leases
git branch --list 'lease/*'            # expect empty - the helper branch is deleted
```

The TEST-000 exception to the normal ticket-finalization proof is safe only because the dry-run
created no commit, `HEAD == baseSha`, and no real ticket was mutated. Never use this shortcut for a
real ticket. An earlier version of this smoke test created an unmerged allow-empty commit and then
deleted it; that exercised the exact unsafe behavior the transaction prohibits.

That last block is not ceremony. `build worktree teardown --require-merged-into <ref>` moves the
integration ancestry proof into the binary; the conductor still verifies ticket finalization and
the lease state immediately before teardown. See `procedure/ticket-transaction.md`, section
`teardown`.

### 8. Report

The Step 0 inventory with line counts; the config added, per section; **both gate runs from Step 3,
verbatim**; the Step 7 output; anything that did not fit.

Do not run a real backlog wave unless the human asks.

## Configuration and credential boundary - read honestly

Do not claim workers have least-privilege ticket access. They do not.

Verified behavior: `build` locates `.build/config.toml` by walking UP from the working directory.
Current Build scopes deterministic command validation correctly: `build worktree`, `build gate`,
and `build waves` load only the sections they consume and do not require `[ticketing]`,
`[workers]`, or `[events]`.

That is not least privilege. A lease under `[worktree].root` is still nested inside the primary
tree, so a worker can read the CONDUCTOR's config file directly. If the repo stores
`plane_api_token` inline in that file rather than in the environment variable named by
`plane_api_token_env`, the worker can read the token with `cat`, no `build` verb required.

What each mechanism actually gives you:

- **The procedure** can enforce that the conductor owns every ticket mutation, and that a worker's
  reported findings - not its actions - are what move a ticket. It cannot make config unreadable.
- **The deny hook** blocks mutating `build` verbs and git-history writes from a linked worktree. It
  is defense in depth. Its limits are stated in its own header: it fails open when `jq` or `git` is
  missing, and it cannot tell a worker from a conductor if the worker's working directory is the
  primary tree. Workers MUST be launched with the lease as their working directory.
- **Prompt enforcement** covers everything else, including "do not read the config".
- **What should change in Throughline Build next:** a sanitized worker-local gate config written
  into the lease at lease time, with `[worktree].root` allowed outside the primary tree once the gate
  no longer needs to walk up to find config.

Practical mitigation available today: keep the token in the environment variable, never inline in
`.build/config.toml`.

## Guardrails (do not loosen)

The procedure defines these per state; this is the installer's checklist for spotting a repo that
has quietly weakened one.

- **Done requires proof, not a verdict** - commit created, integrated, `merge-base --is-ancestor`
  clean, merged gate green, finalization invariants satisfied, final comment recorded.
- **Teardown requires proof, not tidiness** - integration proven, worktree clean, no untracked
  work, ticket finalized. Otherwise the lease stands, and an existing lease is never cleared just
  because a new run started.
- **Never operate on a dirty primary worktree.** No auto-stash, no absorbing unrelated changes.
- **One gate, from config, for everyone**, with four distinct meanings of green.
- **The reviewed candidate is immutable.** Fingerprint tracked content, index content, and
  non-ignored untracked content before review; require the exact same fingerprint and a repeated
  scope check after review before committing.
- **The conductor owns all commits, all ticket state, and the worktree lifecycle.** A worker's
  lease HEAD must still be at `baseSha` when it returns.
- **The declared surface is a fence; widening it is a SCHEDULING decision** checked against every
  active, passed-but-unintegrated, and remaining ticket - not an in-place approval.
- **Only blocking findings cause rework, three rounds maximum, then escalate.**
- **Deploy / merge-to-main / ship NEVER happen inside the loop.** Cap concurrency at 2-3.
- **Do not adopt `build chain`.** A fresh worker CLI per phase pays a cold context load every time;
  keeping one warm conductor is the entire point of this topology.

## Throughline Build assumptions

This kit assumes the installed `build` binary has these command contracts:

1. `build worktree teardown --require-merged-into <ref>` refuses teardown unless the helper branch is
   proven integrated into `<ref>`.
2. `build gate --require-checks` exits non-zero when no selected checks are configured.
3. `build worktree`, `build gate`, and `build waves` use section-scoped config loading; they do not
   require ticketing or worker sections.

Verify those on each machine with `build worktree --help`, `build gate --help`, `build waves --help`,
and `build help config`.

Remaining useful Build improvements:

1. **Conductor-side commit verb:** stage an explicit reviewed candidate on a lease branch and return
   the SHA, using literal pathspecs, index cleanup on failure, and the reviewed candidate
   fingerprint.
2. **Sanitized worker-local config:** write a gate-only config into each lease and support a worktree
   root outside the primary repository. That is the actual config-isolation boundary.
