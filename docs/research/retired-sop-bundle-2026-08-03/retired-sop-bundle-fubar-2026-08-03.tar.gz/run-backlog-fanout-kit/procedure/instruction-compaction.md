# Instruction compaction procedure

Use this when a repository's agent instructions or local backlog skill have grown large and
repetitive. The goal is smaller context with identical behavior: preserve every normative rule,
permission boundary, gate, and safety invariant.

## 1. Inventory before editing

Read all scoped instruction files and create a rule inventory. Account for every `must`, `never`,
`do not`, `only`, `require`, gate instruction, shell rule, ticket rule, branch rule, worker boundary,
and project-specific gotcha. Record source file/line, summary, canonical destination, and whether a
duplicate may become a cross-reference.

## 2. Checkpoint every stage

Archive the exact post-step contents before moving to the next step. A checkpoint should include:

- copied scoped files;
- `manifest.sha256`;
- `word-counts.txt`;
- `diff-from-previous.patch`;
- `analysis.md`.

The analysis answers: what changed, word-count delta, whether behavior changed, duplicate rules
remaining, and proceed/rework/stop.

## 3. Compact from global to local

1. Keep root instructions authoritative and short.
2. Reduce nested files to local deltas: ownership boundaries, embedded-resource warnings, line
   endings, snapshots, local test doubles, and subtree-specific hazards.
3. Keep broad rules in the root: ticket access, branch/commit/push/merge/deploy boundaries, AOT,
   gates, worktrees, ASCII, and no nested worker-spawning verbs.

## 4. Make skills route by reference

For `run-backlog`, `SKILL.md` should carry activation, mode selection, shell contract, conductor
invariants, and final report rules. Detailed serial, fan-out, adaptation, and worker contracts live
in references:

- `references/serial-loop.md`;
- `references/parallel-fan-out.md`;
- `references/repo-adaptation.md`;
- `references/agent-contracts.md`.

Keep worker contracts more explicit than ordinary references because they are pasted or summarized
into delegated worker contexts.

## 5. Validate behavior preservation

Create a final preservation table for every inventory rule:

- preserved unchanged;
- preserved shorter;
- moved;
- intentionally duplicated;
- needs human review.

Run targeted searches for high-risk terms such as ticket backend, direct REST/MCP access,
worker-spawning verbs, AOT/source-generated JSON, reflection, push/merge/deploy, worktree,
reviewer/implementer, Bash/Git Bash, gates, and serialization. Validate files exist and the edited
skill passes the skill validator when available.

## 6. Benchmark against a real run

Use an actual backlog transcript to count:

- repeated worker-instruction motifs;
- repeated conductor fingerprint/status snippets;
- repeated ticket evidence comment shapes;
- estimated tokens saved per worker context;
- estimated savings for an 11-agent run;
- intentional duplicates left in place.

Separate instruction redundancy from workflow ceremony that belongs in Build commands such as
candidate status, worker brief generation, evidence comments, and run summaries.
