1. Copy the kit to the other machine.

   macOS or Windows location:

   ```text
   ~/src/run-backlog-fanout-kit
   ```

2. If you are using Codex on that machine, install/update the skill:

   ```sh
   bash ~/src/run-backlog-fanout-kit/scripts/install-run-backlog-skill.sh
   ```

3. In the target repo, open Claude/Codex from the repo root.

4. Point the agent at **one entry file**, using the block for the target operating system.

## Install Build-backed fan-out

### macOS or Windows

```text
Read ~/src/run-backlog-fanout-kit/README.md completely.
KIT_DIR=~/src/run-backlog-fanout-kit
REPO=<this repo root>

Install/adapt the build-backed run-backlog fan-out kit into this repo.
Do not touch real tickets. Do not deploy, push, or merge.
Run the kit verifier when done.
```

## Remove old hand-rolled fan-out and go serial

### macOS or Windows

```text
Read ~/src/run-backlog-fanout-kit/migrate-from-hand-rolled.md completely.
KIT_DIR=~/src/run-backlog-fanout-kit
REPO=<this repo root>

Simplify this repo to serial run-backlog using Build gate/worktree-safe docs.
Do not touch real tickets. Do not deploy, push, or merge.
Run the kit verifier when done.
```

5. After installation, run the verifier.

### macOS or Windows (Git Bash)

```sh
bash ~/src/run-backlog-fanout-kit/scripts/verify-kit.sh /path/to/target-repo
```

If the target repo keeps `.build/config.toml` local/ignored, create or merge a local config before
running the verifier. For .NET repos with `packages.lock.json`, use
`templates/dotnet-build-config.local.example.toml` as the starter and replace
`{{SOLUTION_OR_PROJECT}}`.

To create a portable archive for another machine:

```sh
bash ~/src/run-backlog-fanout-kit/scripts/package-kit.sh
```

For this repo specifically, Claude `/run-backlog` should already work. The kit is now mostly for installing/updating other repos, or for adding the stricter Claude hook/procedure files if you want this repo to exactly match the portable kit. Do not point agents at `HANDOFF-build-followups-audit.md`; that is background only.
